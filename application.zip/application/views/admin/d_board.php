<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-6 offset-3 mt-5">
                <div class="row">
                    <div class="one col-5 bg-success p-5 m-3">
                        <a href="<?php echo base_url('contacts-details') ?>" class="text-decoration-none">
                            <h3 class="text-center text-light">Contact Us</h3>
                            <h4 class="text-center text-light">
                                <?php
                                    $cd=$this->BMDU_modal->cm();
                                    echo $cd;
                                ?>
                            </h4>
                        </a>
                    </div>
                    <div class="two col-5 bg-warning p-5 m-3">
                        <a href="<?php echo base_url('Hire-details') ?>" class="text-decoration-none">
                            <h3 class="text-center text-light">Hire Us</h3>
                            <h4 class="text-center text-light">
                                <?php
                                    $hd=$this->BMDU_modal->hm();
                                    echo $hd;
                                ?>
                            </h4>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="three col-5 bg-primary p-5 m-3">
                        <a href="<?php echo base_url('Quick-details') ?>" class="text-decoration-none">
                            <h3 class="text-center text-light">Quick Inquary</h3>
                            <h4 class="text-center text-light">
                                <?php
                                    $qd=$this->BMDU_modal->qm();
                                    echo $qd;
                                ?>
                            </h4>
                        </a>
                    </div>
                    <div class="four col-5 bg-info p-5 m-3">
                        <a href="<?php echo base_url('Request-details') ?>" class="text-decoration-none">
                            <h3 class="text-center text-light">Request</h3>
                            <h4 class="text-center text-light">
                                <?php
                                    $rd=$this->BMDU_modal->rm();
                                    echo $rd;
                                ?>
                            </h4>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>