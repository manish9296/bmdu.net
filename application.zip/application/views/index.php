
<!--hero section start-->
<section class="hero-it-solution hero-nine-bg  animate__animated animate__flash" style="background: url(<?php echo base_url('assets/img/hero-9-img.png'); ?>)no-repeat center center">
   <div class="container">
      <div class="row align-items-center">
         <div class="col-lg-6 col-md-10">
            <div class="typing-slider hero-content-wrap mt-5 mt-lg-0 mt-xl-0">
     <h1>Best
      <span class="txt-type" data-wait="3000" data-words='["Digital Marketing", "App Development", "Website Designing", "Website Development", "Graphics Designing", "Social Media Marketing"]'></span><br> Company In India
    </h1>

    
  
    
               
               <p class="lead bmdu_para">
                 BMDU is a <a href="<?php echo base_url('/'); ?>" style="color: #000000a8;">a top digital marketing company and web designing company in India</a> that excels
in all sorts of marketing, advertising, and promotion. The company is a melting pot of vibrant ideas blasting off together to produce excellent customer experiences.

  </p>
               <div class="action-btn align-items-center d-block d-sm-flex d-lg-flex d-md-flex">
                  <a href="<?php echo base_url('request'); ?>" class="btn btn-primary me-3">Request For Demo</a>
                  <a href="https://www.youtube.com/watch?v=IILumnhHlhw" class="text-decoration-none popup-youtube d-inline-flex align-items-center watch-now-btn mt-3 mt-md-0 text-primary">
                     <i class="fas fa-play text-primary border-2 border-primary"></i>
                     Watch Demo
                  </a>
               </div>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="hero-img position-relative my-5 mt-lg-0 text-center">
               <img src="<?php echo base_url('assets/image/Home1.png'); ?>" alt="web designing company" class="img-fluid" />
               
             
            </div>
         </div>
      </div>
   </div>
</section>
<!--hero section end-->
<!-- app two feature three start -->
<section class="services-icon my-5">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-lg-12 col-md-12">
            <div class="section-heading text-center">
               <h2>Services We Provide</h2>
               <p>
                  BMDU has played a prominent role in providing the best of services to its clients
                  across the world with its years of experience in Digital Marketing, Web Designing and
                  Website Development with passionate and approachable teams.
               </p>
            </div>
            
         </div>
      </div>
      <div class="row justify-content-center">
       <!--*******owl crausal start***************-->
       <div class="col-md-4">
             <div class="single-service  p-4 text-center mt-3 shadow-sm">
               <div class="service-icon icon-center">
                 <a href="<?php echo base_url('web-development-services'); ?>"> <img src="<?php echo base_url('assets/img/service/coding.png'); ?>" alt="app development agency" width="65" height="65" /></a>
               </div>
               <div class="service-info-wrap">
                  <h3 class="h5">Web Development</h3>
                  <p>
                     BMDU is the country's best Web development company in Noida consisting of the
                     finest web designers. It is a privately managed software company that delivers
                     effectively optimized website solutions.
                  </p>
                  <a href="/web-development-services" class="link-with-icon text-decoration-none mt-2 btn btn-md">
                 Upgrade Your Website
                  <i class="fas fa-arrow-right"></i>
               </a>
               </div>
            </div>
       </div>
       
       <div class="col-md-4">
            <div class="single-service  p-4 text-center mt-3 shadow-sm">
               <div class="service-icon icon-center">
                 <a href="<?php echo base_url('app-development-services'); ?>"> <img src="<?php echo base_url('assets/img/service/app-development.png'); ?>" alt="app development agency" width="65" height="65" /></a>
               </div>
               <div class="service-info-wrap">
                  <h3 class="h5">App Development</h3>
                  <p>
                     BMDU, the app development agency It provides you with everything that you expect from a Web designing agency while investing. Developers not only work on building an application. but also ensure that it can adapt to change.
                  </p>
                  <a href="/app-development-services" class="link-with-icon text-decoration-none mt-2 btn btn-md">
                 Create Your App
                  <i class="fas fa-arrow-right"></i>
               </a>
               </div>
            </div>
        </div>    
       
       <div class="col-md-4">
             <div class="single-service p-4 text-center mt-3 shadow-sm">
               
               <div class="service-icon icon-center">
                 <a href="<?php echo base_url('web-design-services') ?>"> <img src="<?php echo base_url('assets/img/service/shield.png'); ?>" alt="app development agency" width="65" height="65" /></a>
               </div>
               <div class="service-info-wrap">
                  <h3 class="h5">Website Designing</h3>
                  <p>“The” Web designing company</a>. BMDU makes sure your website has an attractive, responsive, trendy design, crafted with perfect ideas and creativity. The website should be organised enough to make it easier.
                  </p>
                    <a href="/web-design-services" class="link-with-icon text-decoration-none mt-2 btn btn-md">
                 Upgrade Your Webdesign
                  <i class="fas fa-arrow-right"></i>
               </a>
               </div>
             
            </div> 
       </div>
       
       <div class="col-md-4"> 
            <div class="single-service  p-4 text-center shadow-sm">
               <div class="service-icon icon-center">
                 <a href="hire-ui-team">  <img src="<?php echo base_url('assets/img/service/curve.png'); ?>" alt="app development agency" width="65" height="65" /> </a> 
               </div>
               <div class="feature-info-wrap">
                  <h3 class="h5">UI/UX Design</h3>
                  <p>
                    UX/UI designers create a visually stunning and intuitive interface for users of websites, applications, games etc. It helps the audience to grab the attention of the company with unique approaches for boosting sales.
                  </p>
                      <a href="/graphic-design-services" class="link-with-icon text-decoration-none mt-2 btn btn-md">
                 Create Your Brand
                  <i class="fas fa-arrow-right"></i>
               </a>
               </div>
            </div>
       </div>
       
       <div class="col-md-4">
           
        <div class="single-service  p-4 text-center shadow-sm">
               <div class="service-icon icon-center">
               <a href="graphic-design-services">   <img src="<?php echo base_url('assets/img/service/graphic-design.png'); ?>" alt="web designing company" width="65" height="65" /></a>
               </div>
               <div class="feature-info-wrap">
                  <h3 class="h5">Graphics Design</h3>
                  <p>
                    BMDU has a dynamic graphic designers company. The Graphic Design company is dedicated to creating creative designs. We offer brochure design, postcards, pamphlets, Logo, Catalogue, Marketing collateral Design.
                  </p>
                   <a href="/graphic-design-services" class="link-with-icon text-decoration-none mt-2 btn btn-md">
                 Create Your logo
                  <i class="fas fa-arrow-right"></i>
               </a>
               </div>
            </div> 
           
       </div>
       
       <div class="col-md-4">
           <div class="single-service  p-4 text-center shadow-sm">
                 <a href="digital-marketing-team"> 
              <div class="service-icon icon-center">
                <a href="digital-marketing-team"> <img src="<?php echo base_url('assets/img/service/promotion.png'); ?>" alt="web designing company" width="65" height="65" /></a>
               </div>
               <div class="feature-info-wrap">
                  <h3 class="h5">Digital Marketing</h3>
                  <p>
                     Digital marketing plays a crucial role in engaging customers quickly while promoting their business and it helps the companies to grab the attention of the audience with unique approaches for boosting sales to a larger extent.
                  </p>
                   <a href="/digital-marketing-services" class="link-with-icon text-decoration-none mt-2 btn btn-md">
                Get Top Ranking
                  <i class="fas fa-arrow-right"></i>
               </a>
               </div>
            </div>     
       </div>
  </div>
   </div>
</section>
<!-- app two feature three end -->

<!-- About Start -->
<section class="about-new">
   <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-12">
            <div class="about-right">
               <h4 class="text-dark h5 mb-2">Why Choose Us</h4>
               <h2 class="mb-2">
                 What Makes Us stand Out From Other Digital Marketing Company?
               </h2>
               <p>
                 Our Digital Marketing Agency is an all-in-one solution that has so far successfully handled more than 1000 projects and is amongst the leading digital marketing agencies in India. We specialise in:
               </p>
               
               <ul class="list-unstyled d-flex flex-wrap list-two-col mt-4 mb-4">
                  <li class="py-1">
                     <i class="fad fa-check-circle me-2 text-primary"></i>
                     Social Media Marketing
                  </li>
                  <li class="py-1">
                     <i class="fad fa-check-circle me-2 text-primary"></i>
                     Web Designing
                  </li>
                  <li class="py-1">
                     <i class="fad fa-check-circle me-2 text-primary"></i>
                     Graphic designing
                  </li>
                  <li class="py-1">
                     <i class="fad fa-check-circle me-2 text-primary"></i>
                     Video Marketing
                  </li>
                  <li class="py-1">
                     <i class="fad fa-check-circle me-2 text-primary"></i>
                     Search Engine Optimisation
                  </li>
                  <li class="py-1">
                     <i class="fad fa-check-circle me-2 text-primary"></i>
                     UX/UI
                  </li>
               </ul>
             
            </div>
         </div>
      </div>
   </div>
</section>
<!-- About End -->
<!-- tech tabs start -->
<section class="services-icon">
   <div class="container">
       <div class="row">
<div class="col-md-12 p-3 bg-body shadow rounded mb-5">
            <div class="large-box mx-auto text-center py-9 ">
               <h2 class="py-3 parralex">Our Working Process </h2>
               </div>                
   

    <div class="row">
        <div class="col-md-12">
            <div class="timeline-steps aos-init aos-animate" data-aos="fade-up">
                <div class="timeline-step">
                    <div class="timeline-content" data-toggle="popover" data-trigger="hover" data-placement="top" title="" data-content="And here's some amazing content. It's very engaging. Right?" data-original-title="2003">
                        <div class="inner-circle"><img src="assets/img/research.png"></div>
                        <p class="h6 mt-3 mb-1">Research</p>
                        
                    </div>
                </div>
                <div class="timeline-step">
                    <div class="timeline-content" data-toggle="popover" data-trigger="hover" data-placement="top" title="" data-content="And here's some amazing content. It's very engaging. Right?" data-original-title="2004">
                        <div class="inner-circle"><img src="assets/img/designdevelopment.png"></div>
                        <p class="h6 mt-3 mb-1">Design And Development </p>
                       
                    </div>
                </div>
                <div class="timeline-step">
                    <div class="timeline-content" data-toggle="popover" data-trigger="hover" data-placement="top" title="" data-content="And here's some amazing content. It's very engaging. Right?" data-original-title="2005">
                        <div class="inner-circle"><img src="assets/img/feedbackand approvals.png"> </div>
                        <p class="h6 mt-3 mb-1">Feedback and Approvals
</p>
                    </div>
                </div>
                <div class="timeline-step">
                    <div class="timeline-content" data-toggle="popover" data-trigger="hover" data-placement="top" title="" data-content="And here's some amazing content. It's very engaging. Right?" data-original-title="2010">
                        <div class="inner-circle"> <img src="assets/img/launch.png"></div>
                        <p class="h6 mt-3 mb-1">Launch and Testing </p>
                       
                    </div>
                </div>
                <div class="timeline-step mb-0">
                    <div class="timeline-content" data-toggle="popover" data-trigger="hover" data-placement="top" title="" data-content="And here's some amazing content. It's very engaging. Right?" data-original-title="2020">
                        <div class="inner-circle"><img src="assets/img/Maintenance.png"></div>
                        <p class="h6 mt-3 mb-1">Maintenance and Alterations</p>
                     
                    </div>
                </div>
            </div>
        </div>
    </div>

            </div>
</div>
</div>
</section>
<!-- taech tabs end -->



<script>
    $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:3,
            nav:false
        },
        1000:{
            items:5,
            nav:true,
            loop:false
        }
    }
})
</script>

<!--*******owl crausal end***************-->
<!-- portfolio start -->
<section class="portfolio bg-light mb-5 py-3">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-lg-12 col-md-10">
            <div class="section-heading text-center">
               <h2>Our Portfolio</h2>
               <p>
                  BMDU has worked on enough projects to give a fair quote on any project accurately. It has developed digital products for the topmost industries out there in the market.
               </p>
            </div>
         </div>
      </div>
      <div class="row justify-content-center">
         <div class="col-lg-10 col-md-8">
            <div class="tab-button mb-5">
               <ul class="nav nav-pills d-flex justify-content-center" id="pills-tab" role="tablist">
                  <li class="nav-item" role="presentation">
                     <button class="nav-link active" id="pills-all-tab" data-bs-toggle="pill" data-bs-target="#pills-all" type="button" role="tab" aria-controls="pills-all" aria-selected="true">
                        All
                     </button>
                  </li>
                  <li class="nav-item" role="presentation">
                     <button class="nav-link" id="pills-branding-tab" data-bs-toggle="pill" data-bs-target="#pills-branding" type="button" role="tab" aria-controls="pills-branding" aria-selected="false">
                        Branding
                     </button>
                  </li>
                  <li class="nav-item" role="presentation">
                     <button class="nav-link" id="pills-design-tab" data-bs-toggle="pill" data-bs-target="#pills-design" type="button" role="tab" aria-controls="pills-design" aria-selected="false">
                       Website  Design
                     </button>
                  </li>
                  <li class="nav-item" role="presentation">
                     <button class="nav-link" id="pills-logo-tab" data-bs-toggle="pill" data-bs-target="#pills-logo" type="button" role="tab" aria-controls="pills-logo" aria-selected="false">
                       App Development
                     </button>
                  </li>
                  <li class="nav-item" role="presentation">
                     <button class="nav-link" id="pills-web-tab" data-bs-toggle="pill" data-bs-target="#pills-web" type="button" role="tab" aria-controls="pills-web" aria-selected="false">
                        Website Development
                     </button>
                  </li>
               </ul>
            </div>
         </div>
         <div class="tab-content" id="pills-tabContent">
            <!-- All -->
            <div class="tab-pane fade show active" id="pills-all" role="tabpanel" aria-labelledby="pills-all-tab">
               <div class="row">
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio6.jpg'); ?>" alt="web designing company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Website  Design</a>
                              </h5>
                              <div class="categories">
                                 <span>Design,</span>
                                 <span>Web</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/port7.jpg'); ?>" alt="web designing company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Website Development
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>Development</span>
                                 <span>Web</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio1.jpg'); ?>" alt="web designing company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">App Development
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>App,</span>
                                 <span>Development</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio4.jpg'); ?>" alt="web designing company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Digital Marketing
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>Design</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
            
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio3.jpg'); ?>" alt="web designing company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Branding & Corporate Identity
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>Branding,</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  
                        <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio5.jpg'); ?>" alt="web designing company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">UI Design
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>Design</span>
                                
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  
               </div>
            </div>
            <!-- Branding -->
            <div class="tab-pane fade" id="pills-branding" role="tabpanel" aria-labelledby="pills-branding-tab">
               <div class="row">
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio3.jpg'); ?>" alt="Graphic Designer Company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Branding
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>Branding,</span>
                                
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio3.jpg'); ?>" alt="Graphic Designer Company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Website Design
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>Website Design,</span>
                                 <span>Web</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio4.jpg'); ?>" alt="Graphic Designer Company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Digital Marketing
                                 </a>
                              </h5>
                              <div class="categories">
                              
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Design -->
            <div class="tab-pane fade" id="pills-design" role="tabpanel" aria-labelledby="pills-design-tab">
               <div class="row">
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio1.jpg'); ?>" alt="Graphic Designer Company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Website Design</a>
                              </h5>
                              <div class="categories">
                                 <span>Design,</span>
                                 <span>Web</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                
               </div>
            </div>
            <!-- Logo -->
            <div class="tab-pane fade" id="pills-logo" role="tabpanel" aria-labelledby="pills-logo-tab">
               <div class="row">
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio1.jpg'); ?>" alt="Graphic Designer Company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Website Design Project</a>
                              </h5>
                              <div class="categories">
                                 <span>Design,</span>
                                 <span>Web</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio2.jpg'); ?>" alt="Graphic Designer Company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Leafery Branding
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>Branding,</span>
                                 <span>Logo</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio3.jpg'); ?>" alt="Graphic Designer Company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Information Architencure
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>Branding,</span>
                                 <span>Logo</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Web -->
            <div class="tab-pane fade" id="pills-web" role="tabpanel" aria-labelledby="pills-web-tab">
               <div class="row">
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio1.jpg'); ?>" alt="Graphic Designer Company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Website Design Project</a>
                              </h5>
                              <div class="categories">
                                 <span>Design,</span>
                                 <span>Web</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio5.jpg'); ?>" alt="Graphic Designer Company" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Information Architencure
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>Branding,</span>
                                 <span>Logo</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="single-portfolio-item mb-30">
                        <div class="portfolio-item-img">
                           <img src="<?php echo base_url('assets/img/portfolio/portfolio2.jpg'); ?>" alt="Digital Marketing Agency" class="img-fluid" />
                           <div class="portfolio-info">
                              <h5>
                                 <a href="<?php echo base_url('portfolio'); ?>" class="text-decoration-none text-white">Leafery Branding
                                 </a>
                              </h5>
                              <div class="categories">
                                 <span>Branding,</span>
                                 <span>Logo</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- portfolio end -->
<!-- app two customer review start -->
<section class="brand-logo mb-5">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-lg-6 col-md-10">
            <div class="section-heading text-center">
               <h2>Over 500+ Companies Trusted Us</h2>
            
            </div>
         </div>
      </div>
      <div class="row">
         <div class="main-content">
            <div class="owl-carousel owl-theme">
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo1.webp'); ?>">
               </div>
               <!--<div class="item">-->
               <!--   <img src="<?php echo base_url('assets\image\company/logo2.webp'); ?>">-->
               <!--</div>-->
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo5.webp'); ?>">
               </div>
               <!--<div class="item">-->
               <!--   <img src="<?php echo base_url('assets\image\company/logo6.webp'); ?>">-->
               <!--</div>-->
               <!--<div class="item">-->
               <!--   <img src="<?php echo base_url('assets\image\company/logo7.webp'); ?>">-->
               <!--</div>-->
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo8.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo9.webp'); ?>">
               </div>
               <!--<div class="item">-->
               <!--   <img src="<?php echo base_url('assets\image\company/logo10.webp'); ?>">-->
               <!--</div>-->
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo11.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo12.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo13.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo14.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo15.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo16.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo17.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo18.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo19.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo20.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo3.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo21.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo22.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo23.webp'); ?>">
               </div>
               <div class="item">
                  <img src="<?php echo base_url('assets\image\company/logo24.webp'); ?>">
               </div>
            </div>
         </div>
         <div class="owl-theme">
            <div class="owl-controls">
               <div class="custom-nav owl-nav"></div>
            </div>
         </div>
      </div>
</section>
<!-- app two customer review end -->
<!--Testimonial  start -->
<section class="testimonial-section bg-light ptb-120">
   <div class="container">
      <div class="row justify-content-center align-content-center">
         <div class="col-md-12 col-lg-12">
            <div class="section-heading text-center" data-aos="fade-up">
              
               <h2>What’s Clients Say</h2>
               <p>
                  Reviews of clients are as important as any other thing in the company. It makes our brand become a better version every-day.
               </p>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-12">
            <div class="position-relative w-100" data-aos="fade-up" data-aos-delay="50">
               <div class="swiper-container testimonialThreeSwiper">
                  <div class="swiper-wrapper">
                     <div class="swiper-slide p-4 bg-white rounded-custom position-relative shadow-sm">
                        <p>
                           Kudos to the team work that the company clients offer. They are so into the work when it comes to working. The company is a perfect blend of professionalism and hard work.
                        </p>
                        <div class="author d-flex">
                           <div class="author-img me-3">
                              <img src="<?php echo base_url('assets/img/testimonial/author1.jpg'); ?>" alt="Digital Marketing Agency" class="rounded-circle" width="60" height="60" />
                           </div>
                           <div class="author-info">
                              <h6 class="m-0">Suresh agarwal</h6>
                              <!-- <span>Product Designer</span> -->
                              <ul class="review-rate mb-0 list-unstyled list-inline">
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide p-4 bg-white rounded-custom position-relative shadow-sm">
                        <p>
                           Just wow!!! Don’t think twice before consulting them. They are the best when it comes to handing over your business for a boost.
                        </p>
                        <div class="author d-flex">
                           <div class="author-img me-3">
                              <img src="<?php echo base_url('assets/img/testimonial/author3.jpg'); ?>" alt="Digital Marketing Agency" class="rounded-circle" width="60" height="60" />
                           </div>
                           <div class="author-info">
                              <h6 class="m-0">Amna Qureshi</h6>
                              <!-- <span>Product Designer</span> -->
                              <ul class="review-rate mb-0 list-unstyled list-inline">
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide p-4 bg-white rounded-custom position-relative shadow-sm">
                        <p>
                           Had the best experience with them. They did wonders for my brand. A big thank you.
                        </p>
                        <div class="author d-flex">
                           <div class="author-img me-3">
                              <img src="<?php echo base_url('assets/img/testimonial/author2.jpg'); ?>" alt="Digital Marketing Agency" class="rounded-circle" width="60" height="60" />
                           </div>
                           <div class="author-info">
                              <h6 class="m-0">Rajat sharma</h6>
                              <!-- <span>FrontEnd Developer</span> -->
                              <ul class="review-rate mb-0 list-unstyled list-inline">
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                                 <li class="list-inline-item">
                                    <i class="fas fa-star text-warning"></i>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <span class="swiper-button-next"></span>
               <span class="swiper-button-prev"></span>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Testimonial end -->
<!--cat subscribe start-->
<section class="cta-subscribe build text-white ptb-120 position-relative overflow-hidden" style="background-image:url(assets/image/contact.png);box-shadow: inset 0 0 0 2000px rgb(32 106 148 / 53%);    background-size: cover;
}">
   
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-lg-8 col-md-10">
            <div class="subscribe-info-wrap text-center position-relative z-2">
               <div class="section-heading" data-aos="fade-up">
                  <h2>Ready to get started?</h2>
                  <p>We can help you to create your dream website for better business revenue.</p>
               </div>
               <div class="form-block-banner mw-60 m-auto " data-aos="fade-up" data-aos-delay="50">
                  <a href="<?php echo base_url('contact-us'); ?>" class="btn btn-light" style="background-color: #045887; border-color: #045887;">Contact with Us</a>
                  <a href="https://www.youtube.com/watch?v=IILumnhHlhw" class="text-decoration-none text-white popup-youtube d-inline-flex align-items-center watch-now-btn ms-lg-3 ms-md-3 mt-3"><i class="fas fa-play"></i> Watch Demo </a>
               </div>
              
            </div>
         </div>
      </div>
      <!---<div class="bg-circle rounded-circle circle-shape-3 position-absolute  left-5"></div>
      <div class="bg-circle rounded-circle circle-shape-1 position-absolute  right-5"></div>-->
   </div>
</section>
<!--cat subscribe end-->
<!--blog section start-->
<section class="home-blog-section my-5">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-lg-6 col-md-12">
            <div class="section-heading text-center">
             
               <h2>Our Latest News and Update</h2>
               <p>Stay in the loop with Our latest news and updates! From trending topics, our website has got you covered with fresh and informative content on digital marketing.</p>
            </div>
         </div>
      </div>
      <div class="row">
          
          
            <div class="col-lg-4 col-md-6">
            <div class="single-article rounded-custom ">
               <a href="<?php echo base_url('what-steps-is-the-internet-publishing-industry-taking-to-improve-digital-literacy-and-media-education'); ?>" class="article-img">
                  <img src="<?php echo base_url('assets/image/what-steps-is-the-internet-publishing-industry-taking-to-improve-digital-literacy-and-media-education.jpg'); ?>" alt="Latest Google Adword Update 2023" class="img-fluid">
               </a>
               <div class="article-content p-4">
                  <div class="article-category mb-4 d-block">
                     <a href="javascript:;" class="d-inline-block text-dark badge bg-danger-soft">Digital Marketing</a>
                  </div>
                  <a href="<?php echo base_url('what-steps-is-the-internet-publishing-industry-taking-to-improve-digital-literacy-and-media-education'); ?>">
                     <h2 class="h5 article-title limit-2-line-text">What steps is the Internet Publishing Industry taking to improve digital literacy and media education?</h2>
                  </a>
                  <p class="limit-2-line-text">The internet publishing industry is the economic sector that creates and distributes material via the internet. It comprises a diverse spectrum of firms..</p>
                  <a href="javascript:;">
                     <div class="d-flex align-items-center pt-4">
                        <div class="avatar">
                           <img src="<?php echo base_url('assets/image/logo.png'); ?>" alt="Digital Marketing Agency" width="40" class="img-fluid rounded-circle me-3">
                        </div>
                        <div class="avatar-info">
                           <h6 class="mb-0 avatar-name">BMDU</h6>
                           <span class="small fw-medium text-muted">Sept 11, 2023</span>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
          
          
          
          <div class="col-lg-4 col-md-6">
            <div class="single-article rounded-custom ">
               <a href="<?php echo base_url('how-can-improve-website-traffic-through-seo'); ?>" class="article-img">
                  <img src="<?php echo base_url('assets/image/digital-audience-development-and-engagement-trends.jpg'); ?>" alt="Latest Google Adword Update 2023" class="img-fluid">
               </a>
               <div class="article-content p-4">
                  <div class="article-category mb-4 d-block">
                     <a href="javascript:;" class="d-inline-block text-dark badge bg-danger-soft">Digital Marketing</a>
                  </div>
                  <a href="<?php echo base_url('how-can-improve-website-traffic-through-seo'); ?>">
                     <h2 class="h5 article-title limit-2-line-text">How Can You Improve Website Traffic Through Seo?</h2>
                  </a>
                  <p class="limit-2-line-text">SEO may be one of the most sought-after marketing methods in today's ever-expanding digital world. From small to big firms..</p>
                  <a href="javascript:;">
                     <div class="d-flex align-items-center pt-4">
                        <div class="avatar">
                           <img src="<?php echo base_url('assets/image/logo.png'); ?>" alt="Digital Marketing Agency" width="40" class="img-fluid rounded-circle me-3">
                        </div>
                        <div class="avatar-info">
                           <h6 class="mb-0 avatar-name">BMDU</h6>
                           <span class="small fw-medium text-muted">Sept 6, 2023</span>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
         
       <div class="col-lg-4 col-md-6">
            <div class="single-article rounded-custom mb-4 mb-lg-0">
               <a href="<?php echo base_url('important-advice-for-improving-your-search-rankings'); ?>" class="article-img">
                  <img src="<?php echo base_url('assets/image/important-advice-for-improving-your-search-rankings.jpg'); ?>" alt="article" class="img-fluid">
               </a>
               <div class="article-content p-4">
                  <div class="article-category mb-4 d-block">
                     <a href="javascript:;" class="d-inline-block text-dark badge bg-primary-soft">Digital Marketing</a>
                  </div>
                  <a href="<?php echo base_url('important-advice-for-improving-your-search-rankings'); ?>">
                     <h2 class="h5 article-title limit-2-line-text">Important Advice For Improving Your Search Rankings </h2>
                  </a>
                  <p class="limit-2-line-text">SEO, or search engine optimization, is all about making it simpler for search engines such as Google and Bing to accomplish two things</p>
                  <a href="javascript:;">
                    <div class="d-flex align-items-center pt-4">
                        <div class="avatar">
                           <img src="<?php echo base_url('assets/image/logo.png'); ?>" alt="Digital Marketing Agency" width="40" class="img-fluid rounded-circle me-3">
                        </div>
                        <div class="avatar-info">
                           <h6 class="mb-0 avatar-name">BM Digital Utilization</h6>
                           <span class="small fw-medium text-muted">Sept 1, 2023</span>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
   
      </div>
      <div class="row justify-content-center">
         <div class="text-center mt-3">
            <a href="<?php echo base_url('blog'); ?>" class="btn btn-md">View All Article <i class="fas fa-arrow-right"></i></a>
         </div>
      </div>
   </div>
</section>

<!--blog section end-->

<!--tiping text animate-->
  <script> 
    class TypeWriter {
      constructor(txtElement, words, wait = 3000) {
        this.txtElement = txtElement;
        this.words = words;
        this.txt = '';
        this.wordIndex = 0;
        this.wait = parseInt(wait, 8);
        this.type();
        this.isDeleting = false;
      }

      type() {
        // Current index of word
        const current = this.wordIndex % this.words.length;
        // Get full text of current word
        const fullTxt = this.words[current];

        // Check if deleting
        if(this.isDeleting) {
          // Remove char
          this.txt = fullTxt.substring(0, this.txt.length - 1);
        } else {
          // Add char
          this.txt = fullTxt.substring(0, this.txt.length + 1);
        }

        // Insert txt into element
        this.txtElement.innerHTML = `<span class="txt">${this.txt}</span>`;

        // change color for data-text
        this.txtElement.innerHTML = `<span class="txt" style="color: #4ab7e5;">${this.txt}</span>`;

        // Initial Type Speed
        let typeSpeed = 100;

        if(this.isDeleting) {
          typeSpeed /= 2;
        }

        // If word is complete
        if(!this.isDeleting && this.txt === fullTxt) {
          // Make pause at end
          typeSpeed = this.wait;
          // Set delete to true
          this.isDeleting = true;
        } else if(this.isDeleting && this.txt === '') {
          this.isDeleting = false;
          // Move to next word
          this.wordIndex++;
          // Pause before start typing
          typeSpeed = 300;
        }

        setTimeout(() => this.type(), typeSpeed);
      }
    }

    // Init On DOM Load
    document.addEventListener('DOMContentLoaded', init);

    // Init App
    function init() {
      const txtElement = document.querySelector('.txt-type');
      const words = JSON.parse(txtElement.getAttribute('data-words'));
      const wait = txtElement.getAttribute('data-wait');
      // Init TypeWriter
      new TypeWriter(txtElement, words, wait);
    }
    </script>
