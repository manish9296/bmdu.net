
<style>
    ::-webkit-scrollbar {
    width: 3px;
    height: 3px;
    border-radius:10px;
    background-image: linear-gradient(#045887, #196690, #045887);
 
}
.worldrotate{
    position: absolute;
    width: 36%;}
</style>


<!--about header section start-->
<section class="about-header-section ptb-120 position-relative overflow-hidden bg-gradient" style="background: url(<?php echo base_url('assets/img/page-header-bg.svg'); ?>)no-repeat center right">
   <div class="container">
      <div class="row">
         <div class="col-12">
            <div class="section-heading-wrap d-flex justify-content-between z-5 position-relative">
               <div class="about-content-left">
                  <div class="about-info mb-5">
                     <h1 class="display-5">BM Digital Utilization: India’s leading Digital Marketing Company 
                            </h1>
                     <p class="lead" style="color:#fff;">
                        Welcome! Thank you for choosing <a href="<?php echo base_url('/'); ?>" style="color: #ffffffb8;">BM Digital Utilization </a>as your digital marketing partner. We are a dynamic and imaginative force, and our expertise is in developing great strategies for promoting your brand and business online.

                     </p>
                     <a href="<?php echo base_url('career'); ?>" class="btn btn-light mt-4 me-3">Open Positions</a>
                     <a href="<?php echo base_url('#our-team'); ?>" class="btn btn-soft-dark mt-4">Meet Our Team</a>
                  </div>
                  <img src="<?php echo base_url('assets/img/about-img-1.jpg'); ?>" alt="Web Development Agency" class="img-fluid about-img-first mt-5 rounded-custom shadow">
               </div>
               <div class="about-content-right">
                  <img src="<?php echo base_url('assets/img/about-img-2.jpg'); ?>" alt="Web Development Agency" class="img-fluid mb-5 rounded-custom shadow">
                  <img src="<?php echo base_url('assets/img/about-img-3.jpg'); ?>" alt="Web Development Agency" class="rounded-custom about-img-last shadow">
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="bg-white position-absolute bottom-0 h-25 bottom-0 left-0 right-0 z-2 py-5">
   </div>
</section>
<!--about header section end-->


<!--our story section start-->
<section class="our-story-section pt-30 pb-60" style="background: url(<?php echo base_url('assets/img/shape/dot-dot-wave-shape.svg'); ?>)no-repeat left bottom">
   <div class="container">
      <div class="row justify-content-between">
          
         <div class="col-lg-5 col-md-12 order-lg-1">
            <div class="section-heading sticky-sidebar">
               <h2 class="h5 text-dark">Our Story</h2>
             
               <p class="bmdu-p">We started <b>2018</b> with a mutual interest in the rapidly developing <b>digital industry</b>. Established by a group of savvy marketers, IT nerds, and creative thinkers, BMDU set out to change the way companies interact with their customers online.
               <br> <br>
What makes us stand out isn't only that we're well-versed in cutting-edge marketing strategies, but also that we're committed to learning about what makes your company special. Every company has a unique history, and it is our mission to share their tales via innovative digital products. To develop strategies that are not only successful but also visionary, we base our method on a thorough comprehension of market dynamics, customer behavior, and future technology.

               </p>
              <!-- <div class="mt-4">
                  <h6 class="mb-3">We Are Awarded By-</h6>
                  <img src="<?php echo base_url('assets/img/awards-01.svg'); ?>" alt="digital marketing company" class="me-4 img-fluid">
                  <img src="<?php echo base_url('assets/img/awards-02.svg'); ?>" alt="digital marketing company" class="img-fluid">
               </div>-->
            </div>
         </div>
         <div class="col-lg-6 col-md-12 order-lg-0">
            <div class="story-grid-wrapper position-relative">
               <!--animated shape start-->
               <ul class="position-absolute animate-element parallax-element shape-service d-none d-lg-block">
                  <li class="layer" data-depth="0.02">
                     <img src="<?php echo base_url('assets/img/color-shape/image-2.svg'); ?>" alt="digital marketing company" class="img-fluid position-absolute color-shape-2 z-5">
                  </li>
                  <li class="layer" data-depth="0.03">
                     <img src="<?php echo base_url('assets/img/color-shape/feature-3.svg'); ?>" alt="Best web designing services in Noida" class="img-fluid position-absolute color-shape-3">
                  </li>
               </ul>
               <!--animated shape end-->
               <div class="story-grid rounded-custom bg-dark overflow-hidden position-relative">
                
                  <div class="story-item bg-white border">
                     <h3 class="display-5 fw-bold mb-1 text-primary">50+</h3>
                     <h6 class="mb-0">Team Members</h6>
                  </div>
                 
                  <div class="story-item bg-light border">
                     <h3 class="display-5 fw-bold mb-1 text-warning">5 Years</h3>
                     <h6 class="mb-0">In Business</h6>
                  </div>
                  <div class="story-item bg-light border">
                     <h3 class="display-5 fw-bold mb-1 text-danger">200+</h3>
                     <h6 class="mb-0">Clients Worldwide</h6>
                  </div>
                  <div class="story-item bg-white border">
                     <h3 class="display-5 fw-bold mb-1 text-primary">150+</h3>
                     <h6 class="mb-0">Projects Completed</h6>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!--our story section end-->
<!--feature section two start-->


<section class="feature-section-two pt-4 bg-light">

   <div class="container">
      <div class="row align-items-center justify-content-center">
         <div class="col-lg-7 col-md-12">
            <div class="section-heading">
               <h2 class="h5" style="color: #216b94">Why BMDU? </h2>
               <div class="row">
                   <div class="col-md-12 clients-bmdu"> 
                    <div class="row">
                   <div class="col-md-6">
                   <div class="icon-content text-white">
                        <h3 class="h5 text-white">Our relationship with our clients </h3>
                        <p>In addition to providing services, BMDU also forms lasting relationships with its clients. We have a client-centered approach, which means we put our heads together with you to make your dreams a reality. Whether you're a fledgling business looking to create an impression or a well-established company in need of a new digital angle, we can customize our services to match your specific requirements.

                        </p>
                     </div>
                 </div>
                
                      <div class="col-md-6">
                     <div class="icon-content text-white">
                        <h3 class="h5 text-white">An amazing team at your one click </h3>
                        <p>We have specialists in everything from search engine optimization to content creation to social media marketing to data analytics, all working together in a committed team. Because of the breadth of our expertise, we can see each project from all angles and seize chances that others may overlook.
We like challenges and welcome new information, adapting our methods to maintain your company's name at the forefront of the industry. Our track record of success in the digital space speaks for itself; we've assisted many companies in not only surviving but thriving.
Come along with us as we take the first steps towards transforming your website visitors into paying customers, your contacts into lifelong allies, and your hopes into reality. Learn how we may help you harness the potential of a well-planned online presence. Mark your calendars as this is the beginning of your company's digital transformation!

                        </p>
                     </div>
                
                    </div>
                </div>
                
                 <div class="row">
                   <div class="col-md-6">
                     <div class="icon-content">
                        <h3 class="h5 text-white">Cooperative Effort
</h3>
                        <p>Working together is fundamental to our business model       because we realize that the whole is greater than the sum of its parts. Our customers see us as an extension of their team, and we work hard to earn that reputation by putting everyone's talents to good use for them.
We work together with mutual trust and support to provide the best possible service to our customers.
  
                        </p>
                     </div>
               </div>
                  
                   
                    <div class="col-md-6">
                     <div class="icon-content">
                        <h3 class="h5 text-white">Wide-ranging Expertise
</h3>
                        <p>As the industry's go-to digital marketing agency, we have a proven record of success. Our knowledge and experience in a wide range of fields allow us to help companies achieve unprecedented levels of online success. We have continuously used the potential of SEO, social media, PPC, and more by combining strategic insight, creative campaigns, and data-driven tactics, and the results have been exponential. We adjust our methods to the specific needs of each client. We are dedicated to digital innovation and are always pushing the boundaries of digital marketing to create enduring client relationships based on demonstrable results.
  
                        </p>
                     </div>
                 </div>
                  
             </div>     
                  
               
            </div>
            </div> </div>
         </div>
         <div class="col-lg-5 col-md-7">
             <img src="assets/img/mitch-world.webp" alt="Best web designing services in Noida" class="worldrotate" >
            <img src="<?php echo base_url('assets/image/2.png'); ?>" alt="Best web designing services in Noida" class="img-fluid rounded-custom" style="filter: grayscale(100%);margin-top: 7px">
            </div>
         </div>
      </div>
   </div>
</section>
<!--feature section two end-->
<!--team section start-->
<section id="our-team" class="team-section ptb-120" style="background: #216b94;">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-lg-6 col-md-12">
            <div class="section-heading text-center">
               
               <h2 class="text-white">The People Behind BMDU</h2>
               <p class="text-white">The Heart and Soul of Our Organization
               </p>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-lg-3 col-md-6">
            <div class="team-single-wrap mb-5">
               <div class="team-img rounded-custom">
                  <img src="<?php echo base_url('assets/img/team/mohit.jpeg'); ?>" alt="Best web designing services in Noida" class="img-fluid position-relative">
                  <ul class="list-unstyled team-social-list d-flex flex-column mb-0">
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-twitter"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-github"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-facebook-f"></i></a></li>
                  </ul>
               </div>
               <div class="team-info mt-4 text-center text-white">
                  <h5 class="h6 mb-1">Mohit Kumar</h5>
                  <p class="text-muted small mb-0 text-white">Business Development Manager</p>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="team-single-wrap mb-5">
               <div class="team-img rounded-custom">
                  <img src="<?php echo base_url('assets/img/team/vipin.jpg'); ?>" alt="Best web designing services in Noida" class="img-fluid position-relative">
                  <ul class="list-unstyled team-social-list d-flex flex-column mb-0">
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-twitter"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-github"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-facebook-f"></i></a></li>
                  </ul>
               </div>
               <div class="team-info mt-4 text-center">
                  <h5 class="h6 mb-1">Vipin</h5>
                  <p class="text-muted small mb-0">Digital Marketing Head</p>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="team-single-wrap mb-5">
               <div class="team-img rounded-custom">
                  <img src="<?php echo base_url('assets/img/team/abshiek.jpg'); ?>" alt="Web Development Agency" class="img-fluid position-relative">
                  <ul class="list-unstyled team-social-list d-flex flex-column mb-0">
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-twitter"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-github"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-facebook-f"></i></a></li>
                  </ul>
               </div>
               <div class="team-info mt-4 text-center">
                  <h5 class="h6 mb-1">Abshiek Gupta</h5>
                  <p class="text-muted small mb-0">APP Developer</p>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="team-single-wrap mb-5">
               <div class="team-img rounded-custom">
                  <img src="<?php echo base_url('assets/img/team/ashwani.jpg'); ?>" alt="Web Development Agency" class="img-fluid position-relative">
                  <ul class="list-unstyled team-social-list d-flex flex-column mb-0">
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-twitter"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-github"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-facebook-f"></i></a></li>
                  </ul>
               </div>
               <div class="team-info mt-4 text-center">
                  <h5 class="h6 mb-1">Ashwani Singh</h5>
                  <p class="text-muted small mb-0">Graphics Designer</p>
               </div>
            </div>
         </div>
      <!--   <div class="col-lg-3 col-md-6">
            <div class="team-single-wrap mb-5">
               <div class="team-img rounded-custom">
                  <img src="<?php echo base_url('assets/img/team/team-5.jpg'); ?>" alt="Web Development Agency" class="img-fluid position-relative">
                  <ul class="list-unstyled team-social-list d-flex flex-column mb-0">
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-twitter"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-github"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-facebook-f"></i></a></li>
                  </ul>
               </div>
               <div class="team-info mt-4 text-center">
                  <h5 class="h6 mb-1">John Sullivan</h5>
                  <p class="text-muted small mb-0">Front End Developer</p>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="team-single-wrap mb-5">
               <div class="team-img rounded-custom">
                  <img src="<?php echo base_url('assets/img/team/team-6.jpg'); ?>" alt="Web Development Agency" class="img-fluid position-relative">
                  <ul class="list-unstyled team-social-list d-flex flex-column mb-0">
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-twitter"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-github"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-facebook-f"></i></a></li>
                  </ul>
               </div>
               <div class="team-info mt-4 text-center">
                  <h5 class="h6 mb-1">John Sullivan</h5>
                  <p class="text-muted small mb-0">Front End Developer</p>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="team-single-wrap mb-5">
               <div class="team-img rounded-custom">
                  <img src="<?php echo base_url('assets/img/team/team-7.jpg'); ?>" alt="Web Development Agency" class="img-fluid position-relative">
                  <ul class="list-unstyled team-social-list d-flex flex-column mb-0">
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-twitter"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-github"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-facebook-f"></i></a></li>
                  </ul>
               </div>
               <div class="team-info mt-4 text-center">
                  <h5 class="h6 mb-1">John Sullivan</h5>
                  <p class="text-muted small mb-0">Front End Developer</p>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="team-single-wrap mb-5">
               <div class="team-img rounded-custom">
                  <img src="<?php echo base_url('assets/img/team/team-8.jpg'); ?>" alt="Web Development Agency" class="img-fluid position-relative">
                  <ul class="list-unstyled team-social-list d-flex flex-column mb-0">
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-twitter"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-github"></i></a></li>
                     <li class="list-inline-item"><a href="<?php echo base_url('#'); ?>"><i class="fab fa-facebook-f"></i></a></li>
                  </ul>
               </div>
               <div class="team-info mt-4 text-center">
                  <h5 class="h6 mb-1">John Sullivan</h5>
                  <p class="text-muted small mb-0">Front End Developer</p>
               </div>
            </div>
         </div>-->
      </div>
   </div>
</section>
<!--team section end-->
<!--testimonial section start-->
<section class="testimonial-section ptb-120 bg-light">
   <div class="container">
      <div class="row justify-content-center align-content-center">
         <div class="col-md-10 col-lg-6">
            <div class="section-heading text-center">
           
               <h2>What They Say About Us</h2>
               <p>Customer reviews are our best possible way to understand better. They matter, their
                  reviews matter.
               </p>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-12">
            <div class="position-relative w-100">
               <div class="swiper-container testimonialSwiper">
                  <div class="swiper-wrapper">
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="Web Development Agency" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                         <!--  <img src="<?php echo base_url('assets/img/testimonial/1.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt=" digital marketing company">-->
                           <div class="author-info">
                              <h6 class="mb-0"> Rajeev Kumar (Founder)</h6>
                              <small>Miniapparels</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>They provide the Best web designing services in Noida.</h6> -->
                         The digital marketing services provided by this company in Noida are unparalleled. They transformed our online presence and significantly boosted our sales. Their expertise in SEO is commendable
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                        <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                          <!--   <img src="<?php echo base_url('assets/img/testimonial/3.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="digital marketing company">-->
                           <div class="author-info">
                              <h6 class="mb-0">Mr. Oram </h6>
                              <small>NeetFreakClothing</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>Embarrassed by the First Version.</h6> -->
                           The best marketing services we've ever experienced! This Noida-based digital marketing company elevated our brand visibility and brought in substantial traffic. Their SEO strategies are top-notch
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                      <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                       <!--      <img src="<?php echo base_url('assets/img/testimonial/2.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="digital marketing company">-->
                           <div class="author-info">
                              <h6 class="mb-0">Mr. Nishang (CEO)</h6>
                              <small>Errandia</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>Amazing Quiety template!</h6> -->
                          Partnering with this digital marketing company in Noida was a game-changer. Their innovative approach to marketing skyrocketed our business growth. SEO results have been exceptional
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                       <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                       <!--      <img src="<?php echo base_url('assets/img/testimonial/4.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="digital marketing company">-->
                           <div class="author-info">
                              <h6 class="mb-0">Sanchit (Designated Partner)</h6>
                              <small>GTreeNursery</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>Best Template for SAAS Company!</h6> -->
                           We entrusted this Noida digital marketing firm with our brand, and they delivered beyond our expectations. Their SEO expertise and overall marketing strategies are truly the best.
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                        <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     
                     
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                       <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                       <!--      <img src="<?php echo base_url('assets/img/testimonial/5.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="Best web designing services in Noida">-->
                           <div class="author-info">
                              <h6 class="mb-0">Jatin (Marketing Head)</h6>
                              <small>SwiftLoan</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>It is undeniably good!</h6> -->
                          Our journey with this digital marketing company in Noida has been phenomenal. They've elevated our online visibility and engagement. Their SEO efforts have been instrumental.
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                        <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     
                      
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                           <!--  <img src="<?php echo base_url('assets/img/testimonial/5.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="Best web designing services in Noida">-->
                           <div class="author-info">
                              <h6 class="mb-0">Samarjyoti (Marketing Head)</h6>
                              <small>Smartwork</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>It is undeniably good!</h6> -->
                         Kudos to this Noida-based digital marketing company for their outstanding services. Their strategies, including SEO, have immensely improved our online presence and conversion rates.
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                        <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     
                     
                     <!--end-->
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                          <!--   <img src="<?php echo base_url('assets/img/testimonial/5.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="Best web designing services in Noida">-->
                           <div class="author-info">
                              <h6 class="mb-0">Samarjyoti (Marketing Head)</h6>
                              <small>Little Singham</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>It is undeniably good!</h6> -->
                         Working with this digital marketing company in Noida was a delight. Their SEO prowess and marketing strategies have contributed significantly to enhancing our brand's reach.
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                        <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     <!--end-->
                     
                        
                     <!--end-->
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                         <!--    <img src="<?php echo base_url('assets/img/testimonial/5.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="Best web designing services in Noida">-->
                           <div class="author-info">
                              <h6 class="mb-0">Sanjeev Gupta (MD)</h6>
                              <small> Highspirit</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>It is undeniably good!</h6> -->
                         This Noida digital marketing firm is truly the best in the industry. Their services, especially in SEO, have boosted our business remarkably. Highly recommended!
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                        <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     <!--end-->
                     
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                        <!--     <img src="<?php echo base_url('assets/img/testimonial/5.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="Best web designing services in Noida">-->
                           <div class="author-info">
                              <h6 class="mb-0">Hemant Verma (Founder)</h6>
                              <small> Elegance Interior</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>It is undeniably good!</h6> -->
                        Partnering with this digital marketing company in Noida was a decision we celebrate. Their SEO expertise combined with their marketing strategies have brought us substantial growth
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                        <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     <!--end-->
                     
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                         <!--    <img src="<?php echo base_url('assets/img/testimonial/5.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="Best web designing services in Noida">-->
                           <div class="author-info">
                              <h6 class="mb-0">Rajesh Kumar (Founder)</h6>
                              <small>Brand Liaison </small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>It is undeniably good!</h6> -->
                        Exceptional digital marketing services in Noida! This company's SEO tactics and marketing approaches have amplified our brand's visibility and generated impressive results.
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                        <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     <!--end-->
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                         <!--    <img src="<?php echo base_url('assets/img/testimonial/5.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="Best web designing services in Noida">-->
                           <div class="author-info">
                              <h6 class="mb-0">Aman Ranjan (MD)</h6>
                              <small> Vashions</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>It is undeniably good!</h6> -->
                       This Noida-based digital marketing company has truly transformed our online presence. Their SEO strategies and marketing services have contributed to our business growth.
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                        <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     <!--end-->
                     <div class="swiper-slide border border-2 p-5 rounded-custom position-relative">
                        <img src="<?php echo base_url('assets/img/testimonial/quotes-dot.svg'); ?>" alt="digital marketing company" width="100" class="img-fluid position-absolute left-0 top-0 z--1 p-3">
                        <div class="d-flex mb-32 align-items-center">
                         <!--    <img src="<?php echo base_url('assets/img/testimonial/5.jpg'); ?>" class="img-fluid me-3 rounded" width="60" alt="Best web designing services in Noida">-->
                           <div class="author-info">
                              <h6 class="mb-0">Sunil Ticko (Marketing Head)</h6>
                              <small>QBACP</small>
                           </div>
                        </div>
                        <blockquote>
                           <!-- <h6>It is undeniably good!</h6> -->
                        An incredible experience working with this Noida digital marketing firm. Their SEO techniques and marketing efforts have had a profound impact on our brand's success.
                        </blockquote>
                        <ul class="review-rate mb-0 mt-2 list-unstyled list-inline">
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                           <li class="list-inline-item"><i class="fas fa-star text-warning"></i></li>
                        </ul>
                        <img src="<?php echo base_url('assets/img/testimonial/quotes.svg'); ?>" alt="digital marketing company" class="position-absolute right-0 bottom-0 z--1 pe-4 pb-4">
                     </div>
                     <!--end-->
                    
                     
                  </div>
               </div>
               <span class="swiper-button-next"></span>
               <span class="swiper-button-prev"></span>
            </div>
         </div>
      </div>
   </div>
</section>
<!--testimonial section end-->
<!--our location address start-->
<section class="office-address-section ptb-120">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-lg-6 col-md-12">
            <div class="section-heading text-center">
               <h4 class="h5 text-primary"></h4>
               <h2>Our Office</h2>
               <p>Located around the world
                  We are every-where, but where are you?
               </p>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-lg-6 col-md-6 mt-4 mt-lg-0 mt-xl-0">
            <div class="rounded-custom border d-block office-address overflow-hidden z-2" style="background: url(<?php echo base_url('assets/img/noida.jpg'); ?>)no-repeat center center / cover">
               <div class="office-content text-center p-4">
                  <span class="office-overlay"></span>
                  <div class="office-info">
                     <h5>India</h5>
                     <address>
                        H169, H Block, Sector 63, Noida, Uttar Pradesh 201301
                     </address>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-6 col-md-6 mt-4 mt-lg-0 mt-xl-0">
            <div class="rounded-custom border d-block office-address overflow-hidden z-2" style="background: url(<?php echo base_url('assets/img/canada.jpg'); ?>)no-repeat center center / cover">
               <div class="office-content text-center p-4">
                  <span class="office-overlay"></span>
                  <div class="office-info">
                     <h5>CANADA</h5>
                     <address>
                       135 13th Ave SW (Calgary, AB) (CANADA)
                     </address>
                  </div>
               </div>
            </div>
         </div>
         <!-- <div class="col-lg-3 col-md-6 mt-4 mt-lg-0 mt-xl-0">
                     <div class="rounded-custom border d-block office-address overflow-hidden z-2" style="background: url('assets/img/office-img-3.jpg')no-repeat center center / cover">
                         <div class="office-content text-center p-4">
                             <span class="office-overlay"></span>
                             <div class="office-info">
                                 <h5>New York</h5>
                                 <address>
                                     4219 Snowbird Lane <br> St Carthage, <br>New York(NY), 13619
                                 </address>
                             </div>
                         </div>
                     </div>
                     </div>
                     <div class="col-lg-3 col-md-6 mt-4 mt-lg-0 mt-xl-0">
                     <div class="rounded-custom border d-block office-address overflow-hidden z-2" style="background: url('assets/img/office-img-5.jpg')no-repeat center center / cover">
                         <div class="office-content text-center p-4">
                             <span class="office-overlay"></span>
                             <div class="office-info">
                                 <h5>Barlin City</h5>
                                 <address>
                                     Brandenburgische Straße <br> DE. Berlin Kreuzberg, <br>Berlin(CA), 10997
                                 </address>
                             </div>
                         </div>
                     </div>
                     </div> -->
      </div>
   </div>
</section>
<!--our location address end-->
<!--cat subscribe start-->
<section class="cta-subscribe bg-light ptb-120 position-relative overflow-hidden">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-lg-8 col-md-10">
            <div class="subscribe-info-wrap text-center position-relative z-2">
               <div class="section-heading">
                  <h2>Ready to get started?</h2>
                  <p>So are you ready?</p>
               </div>
               <div class="form-block-banner mw-60 m-auto mt-2">
                  <a href="<?php echo base_url('contact-us'); ?>" class="btn btn-primary">Contact with Us</a>
                 
               </div>
               <ul class="nav justify-content-center subscribe-feature-list mt-4">
                  
                  <li class="nav-item">
                     <span><i class="far fa-check-circle text-primary me-2"></i>No credit card required</span>
                  </li>
                  <li class="nav-item">
                     <span><i class="far fa-check-circle text-primary me-2"></i>Support 24/7</span>
                  </li>
                 
               </ul>
            </div>
         </div>
      </div>
      <div class="bg-circle rounded-circle circle-shape-3 position-absolute bg-gradient left-5"></div>
      <div class="bg-circle rounded-circle circle-shape-1 position-absolute bg-light right-5" style="background: radial-gradient(#2eade2, transparent);"></div>
   </div>
</section>
<!--cat subscribe end-->