<?php
defined('BASEPATH') or exit('No direct script access allowed');
class BMDU_modal extends CI_Model
{
    public function create($hire)
    {
        $ins = $this->db->insert('hire_us',$hire);
        if($ins){
            return true;
        } else{
            return false;
        }
    }
    
    public function request_data($req)
    {
        $ins1 = $this->db->insert('request',$req);
        if($ins1){
            return true;
        } else{
            return false;
        }
    }
    
    public function quick_data($quick)
    {
        $ins2 = $this->db->insert('quick_inquary',$quick);
        if($ins2){
            return true;
        } else{
            return false;
        }
    }
    
    public function contact_data($contact)
    {
        $ins3 = $this->db->insert('contact',$contact);
        if($ins3){
            return true;
        } else{
            return false;
        }
    }
    
    public function logg($u,$p)
    {
        $ins3 = $this->db->where(['username'=>$u, 'password'=>$p]);
        $query = $this->db->get('admin');
        if($query->num_rows() > 0){
            return $query->row();
        } else{
            return false;
        }
    }
    
    public function cm()
    {
        return $this->db->count_all('contact');
    }
    
    public function hm()
    {
        return $this->db->count_all('hire_us');
    }
    
    public function qm()
    {
        return $this->db->count_all('quick_inquary');
    }
    
    public function rm()
    {
        return $this->db->count_all('request');
    }
    
    public function ctd_m()
    {
        $this->db->order_by("id", "DESC");
        $cdt = $this->db->get('contact');
        if($cdt){
            return $cdt->result();
        } else{
            return false;
        }
    }
    
    public function hitd_m()
    {
        $this->db->order_by("id", "DESC");
        $hdt = $this->db->get('hire_us');
        if($hdt){
            return $hdt->result();
        } else{
            return false;
        }
    }
    
        public function qud_m()
    {
        $this->db->order_by("id", "DESC");
        $qudt = $this->db->get('quick_inquary');
        if($qudt){
            return $qudt->result();
        } else{
            return false;
        }
    }
    
        public function reqd_m()
    {
        $this->db->order_by("id", "DESC");
        $reqdt = $this->db->get('request');
        if($reqdt){
            return $reqdt->result();
        } else{
            return false;
        }
    }
    
    //     public function ctd_m()
    // {
    //     $cdt = $this->db->get('contact');
    //     if($cdt){
    //         return $cdt->result();
    //     } else{
    //         return false;
    //     }
    // }
}
?>