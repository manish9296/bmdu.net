

<div class="container mt-3">
    <div class="col-sm-6">
  <h2 class="text-center mt-5">Job Post of Career Page</h2>
  <form action="<?php echo base_url('job_apply'); ?>" method="POST">
    <div class="form-floating mt-3 mb-3">
      <input type="text" class="form-control" id="requirement" required name="requirement">
      <label for="requirement">Requirement of Positions</label>
    </div>
    <div class="form-floating mt-3 mb-3">
      <input type="text" class="form-control" id="positions" required name="positions">
      <label for="positions">Position</label>
    </div>
    <div class="form-floating mb-3 mt-3">
      <input type="text" class="form-control" id="job_type" required name="job_type">
      <label for="job_type">Job Type</label>
      
    </div>
    <div class="form-floating mt-3 mb-3">
      <input type="text" class="form-control" id="experience" required name="experience">
      <label for="experience">Requirement of Experience</label>
    </div>
    <div class="form-floating mt-3 mb-3">
      <input type="text" class="form-control" id="salary" required name="salary">
      <label for="salary">Salary</label>
    </div>
    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
  </form>
  </div>
</div>
