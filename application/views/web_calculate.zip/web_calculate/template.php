<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.3/html2pdf.bundle.min.js"></script>
</head>
<body>
  <h1> </h1>  
  <!-- Link to the page where PDF generation occurs -->
  <a href="<?php echo base_url("textpdf"); ?>" id="downloadLink">Download Quotaion</a>

</body>
</html>

